from django.db import models
from transactions.models import  Site
from django.contrib.auth.models import Group

class Group_site(Group):
    site = models.ForeignKey(Site, on_delete=models.CASCADE)
    class Meta:
        verbose_name = 'Группа Менеджеров'
        verbose_name_plural = "Менеджеры"