from django.contrib import admin
from .models import  Group_site

admin.site.register(Group_site)



