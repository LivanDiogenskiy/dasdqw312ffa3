from django import forms
from .models import Order, STATUS_SCHEMA
from django_jsonform.forms.fields import JSONFormField


class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['site', 'status', 'date_created', 'name', 'phone', 'email', 'address', 'comment', 'products', 'total']
        labels = {
            'site': 'Сайт',
            'status': 'Статус',
            'date_created': 'Дата создания заказа',
            'name': 'Имя',
            'phone': 'Телефон',
            'email': 'Email',
            'address': 'Адрес',
            'comment': 'Комментарий',
            'products': 'Товары',
            'total': 'Сумма'
        }
        widgets = {
            'status': forms.Select(choices=STATUS_SCHEMA),
        }
