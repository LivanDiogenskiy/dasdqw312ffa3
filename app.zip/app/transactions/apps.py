import time
import json
import pytz
from woocommerce import API
from datetime import datetime
from multiprocessing import Process

from django.apps import AppConfig


def get_woocommerce_response(domain, consumer_key, consumer_secret):
    try:
        wcapi = API(
            url=domain,
            consumer_key=consumer_key,
            consumer_secret=consumer_secret,
            timeout=50
        )
        response = wcapi.get('orders')
        return response

    except Exception as e:
        return None
        

class SitesListening(Process):
    def __init__(self):
        super().__init__()
        self.daemon = True

    def run(self):
        from .models import Site, Order

        def create_order_from_json(site, json_order):
            status = json_order['status']

            moscow_tz = pytz.timezone('Europe/Moscow')
            date_created = datetime.strptime(json_order["date_created"], '%Y-%m-%dT%H:%M:%S').astimezone(moscow_tz)

            pre_name = json_order['billing']['first_name'] + json_order['billing']['last_name']
            if not pre_name:
                try:
                     pre_name = json_order["meta_data"][0]["value"]
                except:
                    pass
            name = pre_name
            
            phone = json_order['billing']['phone']
            email = json_order['billing']['email']

            address = json_order['billing']['address_1'] + json_order['billing']['city']
            comment = json_order['customer_note']

            products = [
                {
                    "product_name": product_item["name"],
                    "quantity": product_item["quantity"],
                    "meta_data": [
                        {
                            "key_meta_data": meta_item["display_key"],
                            "val_meta_data": meta_item["display_value"]
                        } for meta_item in product_item["meta_data"] 
                    ]
                } for product_item in json_order["line_items"] 
            ]

            total = json_order['total']

            order = Order(
                site=site,
                status=status,
                date_created=date_created,
                name=name,
                phone=phone,
                email=email,
                address=address,
                comment=comment,
                products=products,
                total=total
            )

            order.save()
        


        my_sites = [
            {
                "domain": "https://грядки-на-дачу.рф",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "ck_bbbab769896ead770fd9ee06dea9662456018169",
                "consumer_secret": "cs_ec90719f184673df4ddfc4763216304ee70c1241"
            },
            {
                "domain": "https://грядкипочтой.рф",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "ck_989e16c45ebd6a461c207e73e66a9c82064f66fe",
                "consumer_secret": "cs_995774bba21d70fb39a013aa4cdceac15d9272de"
            },
            {
                "domain": "https://борисовка35.рф",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "",
                "consumer_secret": ""
            },
            {
                "domain": "https://blok-konteiner35.ru",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "",
                "consumer_secret": ""
            },
            {
                "domain": "https://штакетникпочтой.рф",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "ck_2eaee55e9853b43245a45f2baed395facf06dea1",
                "consumer_secret": "cs_83f948c311e29a75e235315b847f6d6ea8c30815"
            },
            {
                "domain": "https://теплица-царица.рф",
                "last_update":  datetime(2023, 6, 6, 10, 30, 0),
                "consumer_key": "ck_60d6b641807616307308631244fc133c62c2da31",
                "consumer_secret": "cs_c87e8c8e48a200de655e915ab9edb7c67c590b9e"
            }
        ]
        for my_site in my_sites:
            try:
                site = Site(
                    domain=my_site["domain"],
                    last_update=my_site["last_update"],
                    consumer_key=my_site["consumer_key"],
                    consumer_secret=my_site["consumer_secret"]
                )
                site.save()
            except:
                pass

        while True:

            sites = Site.objects.all()

            time.sleep(10)

            for site in sites:
                response = get_woocommerce_response(
                    site.domain, 
                    site.consumer_key, 
                    site.consumer_secret
                )
                if not response:
                    continue

                for json_order in response.json():
                    print(json_order)
                    moscow_tz = pytz.timezone('Europe/Moscow')
                    order_date_created = datetime.strptime(json_order["date_created"], '%Y-%m-%dT%H:%M:%S').astimezone(moscow_tz)
                    if site.last_update < order_date_created:
                        create_order_from_json(site, json_order)
                
                utc_now = datetime.utcnow()
                moscow_now = utc_now.replace(tzinfo=pytz.UTC).astimezone(moscow_tz)
                site.last_update = moscow_now
                site.save()
                time.sleep(10)


class TransactionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'transactions'
    def ready(self):
        monitor = SitesListening()
        monitor.start()
