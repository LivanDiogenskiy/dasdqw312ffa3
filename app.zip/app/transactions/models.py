from django.db import models
from django_jsonform.models.fields import JSONField


PRODUCTS_SCHEMA = {
    "type": "array",
    "title": "Список покупок",
    "items": {
        "type": "object",
        "keys": {
            "product_name": {
                "type": "string",
                "title": "Название товара"
            },
            "quantity": {
                "type": "integer",
                "title": "Количество"
            },
            "meta_data": {
                "type": "array",
                "title": "Мета данные",
                "items": {
                    "type": "object",
                    "keys": {
                        "key_meta_data": {
                            "type": "string",
                            "title": "Название свойства"
                        },
                        "val_meta_data": {
                            "type": "string",
                            "title": "Значение свойства"
                        },
                    },
                },
                "minItems": 0,
                "maxItems": 100
            },
        },
    },
    "minItems": 1,
    "maxItems": 100
}

STATUS_SCHEMA = [
    ("pending", "В ожидании платежа"),
    ("failed", "Неуспешно"),
    ("processing", "В обработке"),
    ("completed", "Выполнено"),
    ("on-hold", "В ожидании"),
    ("cancelled", "Отменено"),
    ("refunded", "Возмещено")
]


class Site(models.Model):
    domain = models.CharField(max_length=150, unique=True)
    last_update = models.DateTimeField()
    consumer_key = models.CharField(max_length=150)
    consumer_secret = models.CharField(max_length=150)
    
    def __str__(self):
            return self.domain

    class Meta:
        verbose_name = "Сайт"
        verbose_name_plural = "Сайты"


class Order(models.Model):
    site = models.ForeignKey(Site, on_delete=models.CASCADE)
    status = models.CharField(max_length=50, choices=STATUS_SCHEMA, verbose_name="Статус")
    date_created = models.DateTimeField(verbose_name="Дата создания заказа")
    name = models.CharField(max_length=50, verbose_name="Имя")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    email = models.EmailField(verbose_name="Email")
    address = models.CharField(max_length=50, verbose_name="Адрес")
    comment = models.TextField(blank=True, null=True, verbose_name="Комментарий")
    products = JSONField(schema=PRODUCTS_SCHEMA, verbose_name="Товары")
    total = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Сумма")

    def __str__(self):
        return f"{self.name} ({self.status})"

    class Meta:
        verbose_name = "Заказ"
        verbose_name_plural = "Заказы"

