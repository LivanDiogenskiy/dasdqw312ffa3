from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import (
    View,
    CreateView, 
    UpdateView
)
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib import messages
from .models import Order
from .forms import OrderForm
from django_filters.views import FilterView
from .filters import OrderFilter


class OrderListView(FilterView):
    filterset_class = OrderFilter
    template_name = 'orders.html'
    paginate_by = 10
    def get(self, request):
        if request.user.is_superuser:
            order_list = Order.objects.filter()
        else:
            order_list = Order.objects.filter(site=request.user.groups.values_list('group_site', flat=True).first())
        return render(request, self.template_name, {'object_list' : order_list})


class OrderCreateView(SuccessMessageMixin, CreateView):                               
    model = Order                                                                  
    form_class = OrderForm                                                          
    template_name = "edit_order.html"                                                  
    success_url = '/transactions'                                                    
    success_message = "Заявка успешно создана"                           

    def get_context_data(self, **kwargs):                                       
        context = super().get_context_data(**kwargs)
        context["title"] = 'Новая заявка'
        context["savebtn"] = 'Сохранить'
        return context       


class OrderUpdateView(SuccessMessageMixin, UpdateView):                                 # updateview class to edit product, mixin used to display message
    model = Order                                                                       # setting 'Product' model as model
    form_class = OrderForm                                                              # setting 'ProductForm' form as form
    template_name = "edit_order.html"                                                   # 'edit_product.html' used as the template
    success_url = '/transactions'                                                          # redirects to 'inventory' page in the url after submitting the form
    success_message = "Заявка успешно изменена"                             # displays message when form is submitted

    def get_context_data(self, **kwargs):                                               # used to send additional context
        context = super().get_context_data(**kwargs)
        context["title"] = 'Редактирование заявки'
        context["savebtn"] = 'Обновить заявку'
        context["delbtn"] = 'Удалить заявку'
        return context


class OrderDeleteView(View):                                                            # view class to delete product
    template_name = "delete_order.html"                                                 # 'delete_product.html' used as the template
    success_message = "Заявка успешно удалена"                             # displays message when form is submitted
    
    def get(self, request, pk):
        order = get_object_or_404(Order, pk=pk)
        return render(request, self.template_name, {'object' : order})

    def post(self, request, pk):  
        order = get_object_or_404(Order, pk=pk)
        order.delete()                                              
        messages.success(request, self.success_message)
        return redirect('orders')